package ir.bmi.branches

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import ir.cafebazaar.poolakey.Connection
import ir.cafebazaar.poolakey.Payment
import ir.cafebazaar.poolakey.config.PaymentConfiguration
import ir.cafebazaar.poolakey.config.SecurityCheck
import ir.cafebazaar.poolakey.request.PurchaseRequest

class MainActivity : ComponentActivity() {
    private lateinit var root: FrameLayout
    private var webView: WebView? = null
    private var progressBar: ProgressBar? = null
    private var payment: Payment? = null
    private var paymentConnection: Connection? = null
    private var billingConnected = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = FrameLayout(this)
        setContentView(root)

        if (!BuildConfig.REQUIRE_PURCHASE) {
            showWebApp()
            return
        }

        showLoading("در حال بررسی خرید...")
        setupBazaarBilling()
    }

    private fun setupBazaarBilling() {
        val rsaKey = BuildConfig.BAZAAR_RSA_PUBLIC_KEY.trim()
        if (rsaKey.isBlank() || rsaKey == "PUT_BAZAAR_RSA_PUBLIC_KEY_HERE") {
            showPaywall("کلید RSA بازار هنوز در GitHub Secrets یا تنظیمات build وارد نشده است.")
            return
        }

        val securityCheck = SecurityCheck.Enable(rsaPublicKey = rsaKey)
        val paymentConfig = PaymentConfiguration(localSecurityCheck = securityCheck)
        val paymentInstance = Payment(context = this, config = paymentConfig)
        payment = paymentInstance

        paymentConnection = paymentInstance.connect {
            connectionSucceed {
                billingConnected = true
                checkLifetimePurchase()
            }
            connectionFailed { throwable ->
                billingConnected = false
                showPaywall("اتصال به بازار برقرار نشد: ${throwable.message ?: "خطای نامشخص"}")
            }
            disconnected {
                billingConnected = false
            }
        }
    }

    private fun checkLifetimePurchase() {
        val paymentInstance = payment ?: run {
            showPaywall("پرداخت بازار آماده نیست.")
            return
        }
        val productId = BuildConfig.BAZAAR_PURCHASE_PRODUCT_ID.trim()
        if (productId.isBlank()) {
            showPaywall("شناسه محصول خرید یک‌باره تنظیم نشده است.")
            return
        }

        showLoading("در حال بررسی خرید...")
        paymentInstance.getPurchasedProducts {
            querySucceed { purchasedProducts ->
                val hasLifetimePurchase = purchasedProducts.any { it.productId == productId }
                if (hasLifetimePurchase) {
                    showWebApp()
                } else {
                    showPaywall("خرید فعال برای این حساب بازار پیدا نشد.")
                }
            }
            queryFailed { throwable ->
                showPaywall("بررسی خرید ناموفق بود: ${throwable.message ?: "خطای نامشخص"}")
            }
        }
    }

    private fun startLifetimePurchase() {
        val paymentInstance = payment ?: run {
            showToast("پرداخت بازار آماده نیست. گزینه بررسی خرید را بزنید.")
            return
        }
        if (!billingConnected) {
            showToast("ابتدا باید اتصال به بازار برقرار شود.")
            setupBazaarBilling()
            return
        }

        val request = PurchaseRequest(
            productId = BuildConfig.BAZAAR_PURCHASE_PRODUCT_ID,
            requestCode = 13013,
            payload = "bmi-branches-lifetime-unlock",
            dynamicPriceToken = null
        )

        paymentInstance.purchaseProduct(
            registry = activityResultRegistry,
            request = request
        ) {
            purchaseFlowBegan {
                showToast("صفحه پرداخت بازار باز شد.")
            }
            failedToBeginFlow { throwable ->
                showToast("شروع پرداخت ناموفق بود: ${throwable.message ?: "خطای نامشخص"}")
            }
            purchaseSucceed {
                showToast("خرید با موفقیت انجام شد.")
                checkLifetimePurchase()
            }
            purchaseCanceled {
                showToast("پرداخت توسط کاربر لغو شد.")
            }
            purchaseFailed { throwable ->
                showToast("پرداخت ناموفق بود: ${throwable.message ?: "خطای نامشخص"}")
            }
        }
    }

    private fun showLoading(message: String) {
        root.removeAllViews()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(40, 40, 40, 40)
            setBackgroundColor(Color.rgb(246, 248, 251))
        }
        progressBar = ProgressBar(this)
        val text = TextView(this).apply {
            this.text = message
            textSize = 16f
            setTextColor(Color.rgb(23, 32, 51))
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 0)
        }
        box.addView(progressBar)
        box.addView(text)
        root.addView(box, fullScreenParams())
    }

    private fun showPaywall(status: String) {
        webView?.visibility = View.GONE
        root.removeAllViews()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(34, 34, 34, 34)
            setBackgroundColor(Color.rgb(246, 248, 251))
        }

        val title = TextView(this).apply {
            text = getString(R.string.paywall_title)
            textSize = 24f
            setTextColor(Color.rgb(15, 118, 110))
            gravity = Gravity.CENTER
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        }
        val message = TextView(this).apply {
            text = getString(R.string.paywall_message) + "\n\n" + status
            textSize = 15f
            setTextColor(Color.rgb(51, 65, 85))
            gravity = Gravity.CENTER
            setPadding(0, 18, 0, 20)
            setLineSpacing(6f, 1.0f)
        }
        val buyButton = Button(this).apply {
            text = getString(R.string.buy_button)
            setOnClickListener { startLifetimePurchase() }
        }
        val restoreButton = Button(this).apply {
            text = getString(R.string.restore_button)
            setOnClickListener {
                if (payment == null || !billingConnected) setupBazaarBilling() else checkLifetimePurchase()
            }
        }

        box.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(message, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(buyButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        box.addView(restoreButton, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT).apply { topMargin = 12 })
        root.addView(box, fullScreenParams())
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun showWebApp() {
        root.removeAllViews()
        val wv = WebView(this)
        webView = wv
        val settings = wv.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true
        settings.allowFileAccess = true
        settings.allowContentAccess = true
        settings.textZoom = 100
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.javaScriptCanOpenWindowsAutomatically = false
        settings.allowFileAccessFromFileURLs = false
        settings.allowUniversalAccessFromFileURLs = false

        wv.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url ?: return false
                return handleExternalUrl(url)
            }

            @Deprecated("Deprecated in Android API")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                return handleExternalUrl(Uri.parse(url))
            }
        }
        wv.webChromeClient = WebChromeClient()
        wv.loadUrl("file:///android_asset/index.html")
        root.addView(wv, fullScreenParams())
    }

    private fun handleExternalUrl(uri: Uri): Boolean {
        val scheme = uri.scheme ?: return false
        if (scheme == "file") return false
        return try {
            startActivity(Intent(Intent.ACTION_VIEW, uri))
            true
        } catch (_: Exception) {
            false
        }
    }

    private fun fullScreenParams(): FrameLayout.LayoutParams = FrameLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT,
        ViewGroup.LayoutParams.MATCH_PARENT
    )

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    override fun onResume() {
        super.onResume()
        if (BuildConfig.REQUIRE_PURCHASE && billingConnected && webView != null) {
            checkLifetimePurchase()
        }
    }

    override fun onBackPressed() {
        val wv = webView
        if (wv != null && wv.canGoBack()) {
            wv.goBack()
        } else {
            AlertDialog.Builder(this)
                .setTitle("خروج")
                .setMessage("از برنامه خارج می‌شوید؟")
                .setPositiveButton("بله") { _, _ -> finish() }
                .setNegativeButton("خیر", null)
                .show()
        }
    }

    override fun onDestroy() {
        paymentConnection?.disconnect()
        paymentConnection = null
        webView?.destroy()
        webView = null
        super.onDestroy()
    }
}
