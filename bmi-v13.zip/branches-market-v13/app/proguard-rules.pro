-keep class ir.cafebazaar.poolakey.** { *; }
-dontwarn ir.cafebazaar.poolakey.**
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}
