# BMI Branches - Bazaar Release Project

پروژه Android آماده انتشار برای وب‌اپ جستجوی کد شعبه و پیش‌شماره کارت بانکی.

نسخه وب‌اپ داخل این مسیر قرار دارد:

```text
app/src/main/assets/index.html
```

## قابلیت خرید یک‌باره بازار

برنامه با SDK پرداخت درون‌برنامه‌ای بازار، یعنی Poolakey، آماده شده است. هنگام اجرای نسخه release، اگر `REQUIRE_PURCHASE=true` باشد، کاربر قبل از ورود به برنامه باید خرید یک‌باره برنامه را با حساب بازار انجام داده باشد.

- دکمه «خرید یک‌باره برنامه» از `purchaseProduct` بازار استفاده می‌کند.
- دکمه «بررسی خرید» خریدهای ثبت‌شده کاربر بازار را با `getPurchasedProducts` می‌خواند.
- فقط اگر شناسه محصول خرید با `BAZAAR_PURCHASE_PRODUCT_ID` یکی باشد، WebView اصلی باز می‌شود.
- این محصول نباید مصرف/consume شود؛ چون هدف، دسترسی دائمی پس از یک پرداخت اولیه است.

> توجه: کد داخل اپ دسترسی به محتوای اپ بعد از نصب را کنترل می‌کند. اینکه خود فایل APK یا صفحه دانلود در بازار فقط برای خریداران قابل دانلود باشد، از داخل کد اپ انجام نمی‌شود و باید در پنل توسعه‌دهندگان بازار/مدل انتشار تنظیم شود.

## نوع محصول در پنل بازار

در پنل توسعه‌دهندگان بازار، محصول را به‌صورت پرداخت درون‌برنامه‌ای یک‌باره بساز؛ نه اشتراک ماهانه یا سالانه.

مقدار پیشنهادی برای شناسه محصول:

```text
bmi_branches_lifetime
```

همین مقدار باید در GitHub Secret زیر ثبت شود:

```text
BAZAAR_PURCHASE_PRODUCT_ID
```

## Secrets لازم در GitHub

در رپوزیتوری GitHub مسیر زیر را باز کن:

```text
Settings > Secrets and variables > Actions > New repository secret
```

این secretها را بساز:

```text
SIGNING_KEYSTORE_BASE64
SIGNING_STORE_PASSWORD
SIGNING_KEY_ALIAS
SIGNING_KEY_PASSWORD
BAZAAR_RSA_PUBLIC_KEY
BAZAAR_PURCHASE_PRODUCT_ID
```

## ساخت keystore انتشار

در سیستم خودت اجرا کن:

```bash
./scripts/create-keystore.sh bmi-branches-release.jks bmi_branches_key
```

خروجی Base64 را در secret زیر قرار بده:

```text
SIGNING_KEYSTORE_BASE64
```

رمز keystore و رمز alias را هم در secretهای مربوطه بگذار.

## ساخت APK مناسب بازار در GitHub Actions

بعد از آپلود پروژه در GitHub:

1. تب **Actions** را باز کن.
2. workflow با نام **Build Bazaar Release APK** را اجرا کن.
3. خروجی artifact با نام زیر ساخته می‌شود:

```text
bmi-branches-bazaar-release-apk
```

داخل artifact، فایل زیر برای انتشار در بازار آماده است:

```text
app-release.apk
```

## مشخصات Android

```text
Package name: ir.bmi.branches
Version code: 13
Version name: 1.3.0
Min SDK: 23
Target SDK: 35
Compile SDK: 35
Billing SDK: com.github.cafebazaar.Poolakey:poolakey:2.2.0
Payment mode: One-time non-consumable in-app product
```

## تست محلی بدون قفل خرید

برای تست سریع WebView بدون پرداخت:

```bash
REQUIRE_PURCHASE=false gradle :app:assembleDebug
```

## تست جریان خرید یک‌باره

برای تست واقعی خرید باید:

1. اپ بازار روی گوشی نصب باشد.
2. همین package name در پنل بازار ثبت شده باشد.
3. محصول خرید یک‌باره با شناسه `BAZAAR_PURCHASE_PRODUCT_ID` ساخته شده باشد.
4. کلید RSA همان اپ از پنل بازار در `BAZAAR_RSA_PUBLIC_KEY` قرار گرفته باشد.
5. APK با همان keystore انتشار امضا شده باشد.
6. بعد از پرداخت، گزینه «بررسی خرید» باید دسترسی برنامه را باز کند.
