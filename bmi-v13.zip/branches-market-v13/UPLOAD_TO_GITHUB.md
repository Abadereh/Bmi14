# راهنمای آپلود در GitHub

## روش پیشنهادی

1. فایل ZIP پروژه را Extract کن.
2. وارد پوشه `branches-market-v13` شو.
3. همه فایل‌ها و پوشه‌های داخل آن را انتخاب کن.
4. در GitHub repo، گزینه **Add file > Upload files** را بزن.
5. فایل‌ها را drag/drop کن.
6. پیام commit پیشنهادی:

```text
Prepare Bazaar release Android project with one-time purchase gate
```

7. بعد از commit، تب **Actions** را باز کن و workflow با نام **Build Bazaar Release APK** را اجرا کن.

## Secretهای لازم

```text
SIGNING_KEYSTORE_BASE64
SIGNING_STORE_PASSWORD
SIGNING_KEY_ALIAS
SIGNING_KEY_PASSWORD
BAZAAR_RSA_PUBLIC_KEY
BAZAAR_PURCHASE_PRODUCT_ID
```

## مقدار پیشنهادی محصول بازار

```text
BAZAAR_PURCHASE_PRODUCT_ID=bmi_branches_lifetime
```

این محصول باید در پنل بازار به‌صورت پرداخت یک‌باره ساخته شود؛ نه اشتراک ماهانه یا سالانه.
