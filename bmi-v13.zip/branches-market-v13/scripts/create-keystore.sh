#!/usr/bin/env bash
set -euo pipefail

KEYSTORE_FILE=${1:-bmi-branches-release.jks}
KEY_ALIAS=${2:-bmi_branches_key}

keytool -genkeypair \
  -v \
  -storetype JKS \
  -keystore "$KEYSTORE_FILE" \
  -alias "$KEY_ALIAS" \
  -keyalg RSA \
  -keysize 2048 \
  -validity 10000

echo "Created $KEYSTORE_FILE with alias $KEY_ALIAS"
echo "Base64 for GitHub secret SIGNING_KEYSTORE_BASE64:"
base64 -w 0 "$KEYSTORE_FILE"
echo
